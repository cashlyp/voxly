# ~/.codex/AGENTS.md
# Global guidance loaded by Codex before any work (layered with project AGENTS.md).

## Working agreements (always)
- Behave like a senior engineer: correctness first, then clarity, then speed.
- Prefer small, reviewable diffs; avoid drive-by formatting changes.
- Preserve public APIs and behavior unless explicitly asked to change them.
- Do not introduce new dependencies without explicit approval.
- When uncertain, ask one targeted question or present 2 options with tradeoffs.

## Execution defaults
- Start by restating intent and constraints.
- Read surrounding code before edits; match local conventions.
- Implement minimal viable changes first, then harden.
- Verify with fastest relevant checks and report outcomes.
- If checks cannot run, state exact commands that should be run.

## Integration docs policy (required)
- For Twilio, Vonage, AWS, OpenRouter, Deepgram, and grammY work, use docs-first workflow.
- Run `/home/codespace/.codex/skills/workflow-automation/scripts/workflow-run-integration-audit.sh [repo-root] --check-latest` when repository access is available.
- Always load `/home/codespace/.codex/skills/integration-docs-kit/references/provider-docs-index.md` first.
- Then load provider-specific references from cookbook/playbooks/checklists.
- Use Context7 first for package docs and version compatibility.
- Cross-check provider webhook/auth/payload behavior with official docs before code changes.
- If docs and local code differ, state the mismatch explicitly.

## Refactoring
- Refactor in safe steps: mechanical rename -> extraction -> simplification -> optimization.
- Keep functions named for intent and reduce deeply nested branching.
- Remove dead code only when proven unused (or with approval).

## Review/debug expectations
- For reviews, prioritize bugs, regressions, and edge-case failures over style.
- For debugging, reproduce first, isolate root cause, then patch minimally.
- Always include file references and explain why the issue occurs.

## Preferred MCP/tool usage
- Prefer `fs` for repository inspection/editing.
- Use `openaiDeveloperDocs` for OpenAI/Codex docs and `context7` for third-party docs.
- Use `playwright` when UI/runtime validation is required.
- If a tool fails, continue with safe fallback and state limitation briefly.
- Never expose secrets in logs or outputs.

## Skill routing hints
- Provider/API docs lookup and integration behavior validation -> use `integration-docs-kit`.
- Feature implementation/code generation -> use `intent-codegen`.
- Complex code reading/explanation -> use `legacy-code-explainer`.
- Bug/edge-case/code-risk review -> use `bug-risk-review`.
- Repro + root-cause + fix -> use `debug-fix-playbook`.
- Repetitive setup/refactor/test/migration loops -> use `workflow-automation`.

## Output format (fast + useful)
- Provide a concise plan (3-6 bullets max).
- Then provide a short "What changed" summary:
  - Files touched
  - Key behavior changes
  - Any follow-ups / risks
- Do not paste unified diffs by default.
- Include exact commands to run when relevant.
