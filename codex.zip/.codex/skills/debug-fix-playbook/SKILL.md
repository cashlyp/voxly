---
name: debug-fix-playbook
description: Use when diagnosing failures, reproducing bugs, and delivering verified fixes. Emphasizes reproducibility, hypothesis-driven debugging, minimal patches, and regression prevention.
---

# Debug Fix Playbook

Use this skill for bug triage, root cause analysis, and verified fixes.

## Workflow
1. Reproduce deterministically.
- Capture exact command, input, environment, and observed output.
- Reduce to smallest reproducible case.

2. Establish expected vs actual behavior.
- Define acceptance criteria before changing code.
- Identify first point of divergence in runtime path.

3. Documentation sync for provider/API failures.
- If issue touches Twilio, Vonage, AWS, OpenRouter, Deepgram, or grammY, run:
  - `/home/codespace/.codex/skills/integration-docs-kit/scripts/detect-integration-surface.sh [repo-root]`
  - `/home/codespace/.codex/skills/workflow-automation/scripts/integration-version-report.sh [repo-root] --check-latest`
- Then load:
  - `/home/codespace/.codex/skills/integration-docs-kit/references/provider-docs-index.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/provider-version-watch.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/provider-playbooks.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/integration-cookbook.md`
- Verify failing behavior against current provider docs and expected payload contracts.

4. Hypothesis loop.
- Rank likely causes.
- Add focused instrumentation.
- Validate or eliminate each hypothesis quickly.

5. Apply minimal corrective patch.
- Fix root cause, not just symptom.
- Avoid broad refactors unless required for correctness.

6. Verify.
- Re-run reproduction.
- Run targeted tests and adjacent regression checks.
- Remove temporary debug instrumentation unless requested.

## Output Contract
- Root cause (one sentence).
- What changed and why it fixes the issue.
- Verification commands and outcomes.
- Remaining risks and follow-ups.
- For provider work, list versions and docs checked.

## Guardrails
- No fix without reproduction evidence unless blocked by environment constraints.
- If blocked, state exactly what evidence is missing and what to run next.
