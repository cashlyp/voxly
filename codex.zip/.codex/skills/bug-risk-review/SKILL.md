---
name: bug-risk-review
description: Use when reviewing code for bugs, logic errors, race conditions, security flaws, and unhandled edge cases. Prioritizes findings by severity with precise file references and reproduction guidance.
---

# Bug Risk Review

Use this skill when the user asks for analysis/review focused on correctness and edge cases.

## Review Priorities
1. Correctness and logic integrity.
2. Data loss/corruption risk.
3. Security and authorization flaws.
4. Concurrency/race/timing issues.
5. Resilience and recovery behavior.

## Provider/API Review Augmentation
- For Twilio, Vonage, AWS, OpenRouter, Deepgram, or grammY code, run:
  - `/home/codespace/.codex/skills/integration-docs-kit/scripts/detect-integration-surface.sh [repo-root]`
  - `/home/codespace/.codex/skills/workflow-automation/scripts/integration-version-report.sh [repo-root] --check-latest`
- Then load:
  - `/home/codespace/.codex/skills/integration-docs-kit/references/provider-docs-index.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/provider-version-watch.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/provider-playbooks.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/production-troubleshooting-checklist.md`
- Validate webhook auth, replay protection, status mapping, rate-limit behavior, idempotency, and terminal-state cleanup against docs.

## Finding Checklist
- Input validation and trust boundaries.
- Null/undefined/empty and boundary values.
- Off-by-one/range errors.
- Async error handling and promise lifecycles.
- Retry/idempotency behavior.
- Resource leaks/timeouts/backpressure.
- Inconsistent state transitions.
- Missing test coverage for risky paths.

## Output Format
- Findings first, ordered by severity.
- Each finding includes:
  - Impact.
  - Reproduction or failure scenario.
  - Exact file/line reference.
  - Minimal fix strategy.
- If no findings: state that explicitly and list residual risks.

## Guardrails
- Do not bury critical issues in summaries.
- Avoid style-only comments unless they cause defects.
- Keep recommendations minimal and testable.
