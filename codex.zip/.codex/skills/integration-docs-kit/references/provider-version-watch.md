# Provider Version Watch

Last updated: 2026-03-03T20:32:51Z
Source commands: `npm view <package> version` and `npm view <package> time.modified`

## Latest stable SDK/package versions
- Twilio (`twilio`): `5.12.2` (published `2026-02-18T04:27:31.706Z`)
- Vonage (`@vonage/server-sdk`): `3.26.4` (published `2026-02-25T17:04:50.063Z`)
- AWS Connect (`@aws-sdk/client-connect`): `3.1000.0` (published `2026-02-27T20:00:54.195Z`)
- AWS Pinpoint (`@aws-sdk/client-pinpoint`): `3.1000.0` (published `2026-02-27T20:04:46.925Z`)
- AWS Polly (`@aws-sdk/client-polly`): `3.1000.0` (published `2026-02-27T20:04:55.390Z`)
- AWS Transcribe Streaming (`@aws-sdk/client-transcribe-streaming`): `3.1000.0` (published `2026-02-27T20:06:39.194Z`)
- OpenAI SDK (for OpenRouter-compatible clients) (`openai`): `6.25.0` (published `2026-02-24T19:54:26.189Z`)
- OpenRouter SDK (`@openrouter/sdk`): `0.9.11` (published `2026-02-23T22:58:24.339Z`)
- Deepgram (`@deepgram/sdk`): `4.11.3` (published `2026-02-17T08:18:52.136Z`)
- grammY (`grammy`): `1.41.1` (published `2026-03-02T20:52:20.964Z`)
- grammY conversations (`@grammyjs/conversations`): `2.1.1` (published `2025-11-20T21:31:30.087Z`)

## Breaking change watchlist
- Twilio Node releases: https://github.com/twilio/twilio-node/releases
- Vonage Node SDK releases: https://github.com/Vonage/vonage-node-sdk/releases
- AWS SDK JS v3 releases: https://github.com/aws/aws-sdk-js-v3/releases
- OpenAI Node releases: https://github.com/openai/openai-node/releases
- Deepgram JS SDK migration guide: https://github.com/deepgram/deepgram-js-sdk/blob/main/MIGRATION.md
- grammY releases: https://github.com/grammyjs/grammY/releases
- grammY conversations releases: https://github.com/grammyjs/conversations/releases

## Update policy
1. Refresh this file weekly and before major integration work.
2. On each major version drift, annotate migration risks in implementation/review output.
3. Do not merge major upgrades without running integration parity tests (webhooks, auth, retries, terminal-state cleanup).
