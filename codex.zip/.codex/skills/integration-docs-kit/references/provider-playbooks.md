# Provider Playbooks

Use only sections relevant to detected providers.

## Twilio
### Official docs
- https://www.twilio.com/docs/voice
- https://www.twilio.com/docs/voice/media-streams
- https://www.twilio.com/docs/voice/twiml
- https://www.twilio.com/docs/messaging
- https://www.twilio.com/docs/messaging/api

### Context7 lookup seeds
- `twilio-node`
- `twilio`

### Version-sensitive surfaces
- Voice webhook signature validation and request canonicalization.
- Media Streams event payload fields.
- Messaging status callback event names.

### Production checks
- Reject invalid signature with explicit `401`/`403`.
- Deduplicate status callbacks by event/message/call identifier.
- Ensure terminal statuses always clean runtime state.

## Vonage
### Official docs
- https://developer.vonage.com/en/voice/voice-api/overview
- https://developer.vonage.com/en/voice/voice-api/ncco-reference
- https://developer.vonage.com/en/voice/voice-api/guides/websockets
- https://developer.vonage.com/en/messaging/sms/overview
- https://developer.vonage.com/en/api/sms

### Context7 lookup seeds
- `vonage-node-sdk`
- `@vonage/server-sdk`

### Version-sensitive surfaces
- Signed webhook validation behavior.
- NCCO action schemas and required fields.
- Voice event payload status naming.

### Production checks
- Validate signed callbacks before any mutation.
- Keep status mapping explicit and exhaustive.
- Handle missing/unknown event types without crashing flow.

## AWS
### Official docs
- https://docs.aws.amazon.com/AWSJavaScriptSDK/v3/latest/
- https://docs.aws.amazon.com/connect/latest/APIReference/Welcome.html
- https://docs.aws.amazon.com/pinpoint/latest/apireference/welcome.html
- https://docs.aws.amazon.com/polly/latest/dg/what-is.html
- https://docs.aws.amazon.com/transcribe/latest/dg/streaming.html

### Context7 lookup seeds
- `aws-sdk-js-v3`
- `@aws-sdk/client-connect`

### Version-sensitive surfaces
- SDK v3 command input/output shapes.
- Region, credential resolution, and retry behavior.
- Service-specific quotas and throttling errors.

### Production checks
- Pin retries with jitter/backoff for throttling classes.
- Emit request IDs and provider IDs for traceability.
- Confirm idempotency behavior for outbound actions.

## OpenRouter
### Official docs
- https://openrouter.ai/docs
- https://openrouter.ai/docs/quickstart
- https://openrouter.ai/docs/api-reference/overview
- https://openrouter.ai/models

### Context7 lookup seeds
- `openai-node`
- `openai`

### Version-sensitive surfaces
- OpenAI-compatible endpoint shape for chosen client SDK.
- Required headers for attribution/routing when configured.
- Model capability differences and streaming behavior.

### Production checks
- Ensure base URL and model allowlist are explicit.
- Guard fallback behavior when model is unavailable.
- Log provider/model/request metadata without leaking prompt secrets.

## Deepgram
### Official docs
- https://developers.deepgram.com/docs
- https://developers.deepgram.com/reference/listen-live
- https://developers.deepgram.com/reference/text-to-speech

### Context7 lookup seeds
- `deepgram-js-sdk`
- `@deepgram/sdk`

### Version-sensitive surfaces
- Live transcription event names and schema.
- Stream format options (`encoding`, `sample_rate`, `model`).
- Connection lifecycle and reconnect expectations.

### Production checks
- Handle stream interruptions and reconnect deterministically.
- Validate transcript event ordering assumptions.
- Track session IDs and audio correlation IDs.

## grammY
### Official docs
- https://grammy.dev/
- https://grammy.dev/guide/
- https://grammy.dev/guide/commands.html
- https://grammy.dev/plugins/conversations

### Context7 lookup seeds
- `grammy`
- `@grammyjs/conversations`

### Version-sensitive surfaces
- Middleware ordering and context mutation semantics.
- Conversations plugin lifecycle and persistence handling.
- Telegram update types and command routing behavior.

### Production checks
- Keep middleware ordering explicit and tested.
- Ensure bot token handling and error middleware are present.
- Confirm long-polling/webhook mode is configured intentionally.
