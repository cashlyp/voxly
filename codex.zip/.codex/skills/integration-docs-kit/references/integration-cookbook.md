# Integration Cookbook (Node.js / TypeScript)

Use these samples as copy/paste starters. Confirm option names against current docs for your installed version.

## Shared helpers

### Exponential backoff with jitter
```ts
export async function withBackoff<T>(
  fn: () => Promise<T>,
  maxAttempts = 5,
  baseMs = 250,
): Promise<T> {
  let lastErr: unknown;
  for (let attempt = 1; attempt <= maxAttempts; attempt += 1) {
    try {
      return await fn();
    } catch (err) {
      lastErr = err;
      if (attempt === maxAttempts) break;
      const jitter = Math.floor(Math.random() * 100);
      const delay = baseMs * 2 ** (attempt - 1) + jitter;
      await new Promise((r) => setTimeout(r, delay));
    }
  }
  throw lastErr;
}
```

### Idempotency guard (Redis-like)
```ts
export async function ensureOnce(key: string, ttlSec: number, setNx: (k: string, ttl: number) => Promise<boolean>) {
  const won = await setNx(key, ttlSec);
  return won; // true => first process, false => duplicate
}
```

## Twilio

### Auth + basic SMS
```ts
import twilio from 'twilio';

const client = twilio(process.env.TWILIO_ACCOUNT_SID!, process.env.TWILIO_AUTH_TOKEN!);

await withBackoff(() =>
  client.messages.create({
    from: process.env.TWILIO_NUMBER!,
    to: '+15555550123',
    body: 'Hello from Twilio',
  }),
);
```

### Webhook signature verification (Express)
```ts
import twilio from 'twilio';

function verifyTwilio(req: any) {
  const sig = req.header('X-Twilio-Signature') || '';
  const url = `${process.env.PUBLIC_BASE_URL}${req.originalUrl}`;
  return twilio.validateRequest(process.env.TWILIO_AUTH_TOKEN!, sig, url, req.body);
}
```

### Pagination (messages)
```ts
const page = await client.messages.page({ pageSize: 50 });
for (const msg of page.instances) {
  console.log(msg.sid, msg.status);
}
```

## Vonage

### Auth + basic SMS (REST)
```ts
const body = new URLSearchParams({
  api_key: process.env.VONAGE_API_KEY!,
  api_secret: process.env.VONAGE_API_SECRET!,
  to: '15555550123',
  from: 'VONAGE',
  text: 'Hello from Vonage',
});

await withBackoff(() =>
  fetch('https://rest.nexmo.com/sms/json', {
    method: 'POST',
    headers: { 'content-type': 'application/x-www-form-urlencoded' },
    body,
  }).then((r) => r.json()),
);
```

### Voice answer webhook (NCCO)
```ts
app.get('/vonage/answer', (req, res) => {
  res.json([
    {
      action: 'talk',
      text: 'Connected',
    },
  ]);
});
```

### Callback dedupe
```ts
const dedupeKey = `vonage:${req.body.uuid}:${req.body.status}`;
if (!(await ensureOnce(dedupeKey, 3600, redisSetNx))) return res.sendStatus(200);
```

## AWS (SDK v3)

### Auth + basic Connect request
```ts
import { ConnectClient, StartOutboundVoiceContactCommand } from '@aws-sdk/client-connect';

const connect = new ConnectClient({ region: process.env.AWS_REGION });

await withBackoff(() =>
  connect.send(new StartOutboundVoiceContactCommand({
    InstanceId: process.env.CONNECT_INSTANCE_ID!,
    ContactFlowId: process.env.CONNECT_FLOW_ID!,
    DestinationPhoneNumber: '+15555550123',
    Attributes: { requestId: crypto.randomUUID() },
  })),
);
```

### Pagination (SDK paginator pattern)
```ts
import { ConnectClient, paginateListUsers } from '@aws-sdk/client-connect';

const paginator = paginateListUsers({ client: new ConnectClient({ region: process.env.AWS_REGION }) }, {
  InstanceId: process.env.CONNECT_INSTANCE_ID!,
});

for await (const page of paginator) {
  for (const user of page.UserSummaryList ?? []) {
    console.log(user.Id);
  }
}
```

### Streaming (Transcribe)
```ts
import { TranscribeStreamingClient, StartStreamTranscriptionCommand } from '@aws-sdk/client-transcribe-streaming';

const transcribe = new TranscribeStreamingClient({ region: process.env.AWS_REGION });
await transcribe.send(new StartStreamTranscriptionCommand({
  LanguageCode: 'en-US',
  MediaEncoding: 'pcm',
  MediaSampleRateHertz: 8000,
  AudioStream: yourAsyncIterableAudio(),
}));
```

## OpenRouter

### Auth + basic chat request (OpenAI SDK compatible)
```ts
import OpenAI from 'openai';

const client = new OpenAI({
  apiKey: process.env.OPENROUTER_API_KEY,
  baseURL: 'https://openrouter.ai/api/v1',
});

const out = await withBackoff(() =>
  client.chat.completions.create({
    model: 'openai/gpt-4.1-mini',
    messages: [{ role: 'user', content: 'Hello' }],
    extra_headers: {
      'HTTP-Referer': process.env.APP_URL,
      'X-Title': 'MyApp',
    },
  }),
);
```

### Streaming
```ts
const stream = await client.chat.completions.create({
  model: 'openai/gpt-4.1-mini',
  stream: true,
  messages: [{ role: 'user', content: 'Stream this.' }],
});

for await (const event of stream) {
  process.stdout.write(event.choices?.[0]?.delta?.content ?? '');
}
```

## Deepgram

### Auth + live transcription
```ts
import { createClient, LiveTranscriptionEvents } from '@deepgram/sdk';

const dg = createClient(process.env.DEEPGRAM_API_KEY!);
const conn = dg.listen.live({
  model: 'nova-2',
  encoding: 'mulaw',
  sample_rate: '8000',
});

conn.on(LiveTranscriptionEvents.Transcript, (evt) => {
  console.log(evt.channel?.alternatives?.[0]?.transcript);
});
```

### Callback dedupe pattern
```ts
const key = `deepgram:${callback.id}:${callback.metadata?.request_id ?? 'none'}`;
if (!(await ensureOnce(key, 3600, redisSetNx))) return;
```

## grammY

### Auth + basic bot + command
```ts
import { Bot } from 'grammy';

const bot = new Bot(process.env.BOT_TOKEN!);
bot.command('start', (ctx) => ctx.reply('Ready'));
await bot.start();
```

### Webhook mode + secret token check
```ts
app.post('/telegram/webhook', (req, res, next) => {
  const header = req.header('X-Telegram-Bot-Api-Secret-Token');
  if (header !== process.env.TELEGRAM_WEBHOOK_SECRET) return res.sendStatus(403);
  next();
});
```

### Retry-after handling for 429
```ts
bot.catch(async (err) => {
  const retryAfter = (err as any)?.error?.parameters?.retry_after;
  if (retryAfter) {
    await new Promise((r) => setTimeout(r, retryAfter * 1000));
    return;
  }
  throw err;
});
```

## What to verify for every sample
- Auth secrets are loaded from env/secret manager.
- Retry only on transient failures (`429`, `5xx`, network timeouts).
- Callback handlers are idempotent.
- Logs include request/correlation IDs, never secrets.
