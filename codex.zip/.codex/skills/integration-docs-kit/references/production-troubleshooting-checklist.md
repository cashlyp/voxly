# Production Troubleshooting Checklist

Use this checklist for incidents, release readiness, and integration hardening.

## Timeouts and retries
- Explicit connect/read/request timeouts are set for every outbound call.
- Retry policy retries only transient errors (`429`, `408`, `5xx`, network failures).
- Backoff uses jitter to prevent synchronized retry storms.
- Max attempts and timeout budget are bounded per request path.

## Rate limits and quota handling
- `429` responses are parsed and handled with provider-specific hints (e.g., `retry_after`).
- Client-side token bucket/concurrency limiter is present for bursty workflows.
- Quota dashboards/alerts are configured (provider + account level).
- Degraded mode behavior is defined for quota exhaustion.

## Webhook/callback security
- Signature/JWT verification is enabled and tested for every inbound provider callback.
- Request timestamp / replay-window checks are enforced when provider supports them.
- Raw body handling matches provider signature canonicalization requirements.
- Unauthorized callbacks fail closed (`401` or `403`) and are observable.

## Idempotency and state safety
- Callback/event handlers dedupe by stable key (`provider-id + event/status`).
- Terminal state transitions are monotonic and cannot regress.
- Retries do not trigger duplicate sends/calls/side effects.
- Dead-letter or poison-message handling is defined.

## Logging, metrics, tracing
- Logs include provider, request ID, message/call ID, status transitions.
- Metrics include success rate, retries, throttles, latency, callback lag.
- Traces stitch outbound requests to inbound callbacks with correlation IDs.
- Redaction policy ensures secrets/PII are never logged.

## Testing and sandboxes
- Unit tests cover signature verification and malformed payloads.
- Integration tests run against provider test credentials/sandbox numbers where available.
- Replay tests validate duplicate callback handling.
- Failure injection covers timeout, `429`, `5xx`, and network partitions.

## Incident triage runbook
1. Identify provider(s), endpoint(s), and error-rate spike window.
2. Confirm auth/signature regressions first (most common hard-fail cause).
3. Check rate-limit/quota telemetry and retry amplification.
4. Verify callback backlog/latency and idempotency behavior.
5. Apply feature flag or degraded mode if user impact continues.
6. Capture exact failed payloads/headers (redacted) for postmortem.
