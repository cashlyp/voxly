# Provider Routing

Use this file first to decide which provider references to load.

## Dependency -> Provider Map
- `twilio` -> Twilio
- `@vonage/server-sdk` -> Vonage
- `@aws-sdk/client-connect`, `@aws-sdk/client-pinpoint`, `@aws-sdk/client-polly`, `@aws-sdk/client-transcribe-streaming` -> AWS
- `openai` with `baseURL=https://openrouter.ai/api/v1` or explicit `openrouter` usage -> OpenRouter
- `@deepgram/sdk` -> Deepgram
- `grammy`, `@grammyjs/*` -> grammY

## Runtime Signal -> Provider Map
- `TWILIO_`, `X-Twilio-Signature`, `twiml`, `VoiceResponse` -> Twilio
- `VONAGE_`, `NCCO`, `x-nexmo-signature`, `x-vonage-signature` -> Vonage
- `AWS_`, `ConnectClient`, `StartOutboundVoiceContact`, `PinpointClient` -> AWS
- `OPENROUTER_`, `openrouter.ai`, `X-Title`, `HTTP-Referer` -> OpenRouter
- `DEEPGRAM_`, `listen.live`, `LiveTranscriptionEvents` -> Deepgram
- `grammy`, `Bot(`, `@grammyjs/conversations` -> grammY

## Minimal Loading Rule
1. Load only provider sections detected from dependencies and runtime signals.
2. For multi-provider repos, keep evidence grouped by provider.
3. Avoid loading unrelated provider content unless failover routing requires it.
