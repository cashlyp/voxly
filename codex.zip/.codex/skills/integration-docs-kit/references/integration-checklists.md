# Integration Checklists (Quick Pass)

Use this file for rapid correctness checks. For production gates, also run:
- `/home/codespace/.codex/skills/integration-docs-kit/references/production-troubleshooting-checklist.md`

## Call Flow Checklist (Twilio/Vonage/AWS)
- Outbound call creation validates required credentials, URLs, and environment.
- Inbound answer path is authenticated and idempotent.
- Event/status webhooks dedupe duplicate callbacks.
- Terminal statuses trigger cleanup for runtime state and in-memory maps.
- Stream auth is enforced (or explicit risk accepted and documented).
- Retries/failover rules are deterministic and observable.
- Provider-specific transfer/hangup parity is explicit.

## SMS Checklist
- Provider adapter supports send + status fetch/reconcile or explicit unsupported status.
- Inbound webhook parsing supports provider-specific payload shape.
- Inbound webhook auth is provider-specific and strict in production.
- Delivery status path updates DB status to terminal states.
- Idempotency and retry logic avoid duplicate sends.
- Circuit breaker and failover telemetry are emitted.

## Security Checklist
- Signature/JWT verification uses timing-safe comparisons.
- Replay prevention exists for signed callbacks (jti/timestamp windows).
- Raw-body hashing uses provider-expected canonical format.
- Secrets never logged.
- Unauthorized webhook behavior is explicit (`401`/`403`) and intentional.

## Observability Checklist
- Emit provider, call/message ID, and status transitions.
- Track retry counts, failover actions, and circuit states.
- Capture degraded modes and fallback activations.
- Include correlation/request IDs across webhook and internal actions.
