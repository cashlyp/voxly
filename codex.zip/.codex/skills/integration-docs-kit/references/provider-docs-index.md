# Provider Docs Index (Source of Truth)

This file is the canonical docs index for provider integrations in Codex skills.

## How to use
1. Detect relevant providers first with:
- `/home/codespace/.codex/skills/integration-docs-kit/scripts/detect-integration-surface.sh [repo-root]`
2. Read only the sections for detected providers.
3. For SDK versions, also read:
- `/home/codespace/.codex/skills/integration-docs-kit/references/provider-version-watch.md`

## Twilio
- Docs home: https://www.twilio.com/docs
- API refs:
  - Voice API Calls resource: https://www.twilio.com/docs/voice/api/call-resource
  - Messaging API Messages resource: https://www.twilio.com/docs/messaging/api/message-resource
- SDK docs:
  - Node helper library repo: https://github.com/twilio/twilio-node
- Webhooks/callbacks:
  - Webhooks overview: https://www.twilio.com/docs/usage/webhooks
  - Webhook security/signature validation: https://www.twilio.com/docs/usage/webhooks/webhooks-security
- Auth/security:
  - API keys: https://www.twilio.com/docs/iam/api-keys
- Errors:
  - Error dictionary: https://www.twilio.com/docs/api/errors
  - 429 error reference (example): https://www.twilio.com/docs/api/errors/20429
- Rate limits/throughput:
  - Messaging throughput and scaling: https://www.twilio.com/docs/messaging/guides/best-practices-at-scale
- Changelog/releases:
  - Releases: https://github.com/twilio/twilio-node/releases

## Vonage
- Docs home: https://developer.vonage.com/
- API refs:
  - Voice API reference: https://developer.vonage.com/en/api/voice
  - SMS API reference: https://developer.vonage.com/en/api/sms
- SDK docs:
  - Node server SDK repo: https://github.com/Vonage/vonage-node-sdk
- Webhooks/callbacks:
  - Webhooks concepts: https://developer.vonage.com/en/getting-started/concepts/webhooks
  - Voice event webhook reference: https://developer.vonage.com/en/voice/voice-api/webhook-reference
- Auth/security:
  - Authentication concepts: https://developer.vonage.com/en/concepts/guides/authentication
- Errors:
  - SMS troubleshooting: https://developer.vonage.com/en/messaging/sms/guides/troubleshooting-sms
- Rate limits/throughput:
  - HTTP 429 support article: https://api.support.vonage.com/hc/en-us/articles/4408659704476-Why-do-I-get-429-Too-Many-Requests-when-I-try-to-send-an-SMS
- Changelog/releases:
  - Releases: https://github.com/Vonage/vonage-node-sdk/releases

## AWS (Connect, Pinpoint, Polly, Transcribe, SDK v3)
- Docs home:
  - AWS SDK for JavaScript v3 developer guide: https://docs.aws.amazon.com/sdk-for-javascript/v3/developer-guide/welcome.html
- API refs:
  - Connect API reference: https://docs.aws.amazon.com/connect/latest/APIReference/Welcome.html
  - Pinpoint API reference: https://docs.aws.amazon.com/pinpoint/latest/apireference/welcome.html
  - Polly docs: https://docs.aws.amazon.com/polly/latest/dg/what-is.html
  - Transcribe streaming: https://docs.aws.amazon.com/transcribe/latest/dg/streaming.html
- SDK docs:
  - AWS SDK JS v3 repo: https://github.com/aws/aws-sdk-js-v3
- Webhooks/callback equivalents:
  - EventBridge events reference (service events): https://docs.aws.amazon.com/eventbridge/latest/ref/events-ref-connect.html
- Auth/security:
  - Credential providers and auth in Node.js: https://docs.aws.amazon.com/sdk-for-javascript/v3/developer-guide/setting-credentials-node.html
- Errors:
  - Common errors: https://docs.aws.amazon.com/connect/latest/APIReference/CommonErrors.html
- Rate limits/quotas:
  - AWS Service Quotas: https://docs.aws.amazon.com/servicequotas/latest/userguide/intro.html
- Changelog/releases:
  - AWS SDK JS v3 releases: https://github.com/aws/aws-sdk-js-v3/releases

## OpenRouter
- Docs home: https://openrouter.ai/docs
- API refs:
  - API overview: https://openrouter.ai/docs/api-reference/overview
  - Parameters: https://openrouter.ai/docs/api-reference/parameters
  - Models: https://openrouter.ai/models
- SDK docs:
  - OpenRouter SDK package: https://www.npmjs.com/package/@openrouter/sdk
  - OpenAI SDK (commonly used with OpenRouter base URL): https://github.com/openai/openai-node
- Webhooks/callbacks:
  - No first-party webhook contract for standard chat completions; use client-side retry/trace patterns.
- Auth/security:
  - Quickstart/auth headers: https://openrouter.ai/docs/quickstart
- Errors:
  - Error codes: https://openrouter.ai/docs/api-reference/errors
- Rate limits/quotas:
  - Limits: https://openrouter.ai/docs/api-reference/limits
- Changelog/releases:
  - Changelog/updates: https://openrouter.ai/changelog

## Deepgram
- Docs home: https://developers.deepgram.com/docs
- API refs:
  - Live transcription reference: https://developers.deepgram.com/reference/listen-live
  - Text-to-speech reference: https://developers.deepgram.com/reference/text-to-speech
- SDK docs:
  - JS SDK repo: https://github.com/deepgram/deepgram-js-sdk
- Webhooks/callbacks:
  - Callback concept docs: https://developers.deepgram.com/docs/callback
- Auth/security:
  - Authentication docs: https://developers.deepgram.com/docs/authentication
- Errors:
  - Errors docs: https://developers.deepgram.com/docs/errors
- Rate limits/quotas:
  - API rate limits: https://developers.deepgram.com/docs/api-rate-limits
- Changelog/releases:
  - JS SDK releases: https://github.com/deepgram/deepgram-js-sdk/releases

## grammY (plus Telegram Bot API)
- Docs home: https://grammy.dev/
- API refs:
  - grammY guide: https://grammy.dev/guide/
  - Telegram Bot API reference: https://core.telegram.org/bots/api
- SDK/docs:
  - grammY repo: https://github.com/grammyjs/grammY
  - conversations plugin docs: https://grammy.dev/plugins/conversations
- Webhooks/callbacks:
  - grammY deployment/webhooks guide: https://grammy.dev/guide/deployment-types.html
  - Telegram `setWebhook`: https://core.telegram.org/bots/api#setwebhook
- Auth/security:
  - Telegram webhook secret token support: https://core.telegram.org/bots/api#setwebhook
- Errors:
  - grammY error handling: https://grammy.dev/guide/errors.html
  - Telegram Bot API response params (`retry_after`): https://core.telegram.org/bots/api#responseparameters
- Rate limits/quotas:
  - Telegram Bot FAQ limits guidance: https://core.telegram.org/bots/faq#my-bot-is-hitting-limits-how-do-i-avoid-this
- Changelog/releases:
  - grammY releases: https://github.com/grammyjs/grammY/releases
  - conversations plugin releases: https://github.com/grammyjs/conversations/releases

## Similar providers (extension pattern)
For additional providers (e.g., Plivo, Telnyx, AssemblyAI), mirror the same categories:
- Docs home
- API refs
- SDK docs
- Webhooks/callbacks
- Auth/security
- Errors
- Rate limits/quotas
- Changelog/releases
