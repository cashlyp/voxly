---
name: integration-docs-kit
description: Use when work touches Twilio, Vonage, AWS, OpenRouter, Deepgram, or grammY. Detects integration surface, maps to official docs + Context7, and enforces evidence-backed implementation/review.
---

# Integration Docs Kit

Use this skill whenever implementation, review, or debugging includes telephony, messaging, speech, or bot-provider integrations.

## Coverage
- Twilio
- Vonage
- AWS (Connect, Pinpoint, Polly, Transcribe, SDK v3)
- OpenRouter
- Deepgram
- grammY
- Similar providers using the same doc-index pattern

## Fast Start (deterministic)
1. Detect provider surface first.
- Run `scripts/detect-integration-surface.sh [repo-root]`.
- If OpenRouter may be present but not explicitly referenced in code strings, run:
  - `scripts/detect-integration-surface.sh [repo-root] --include-openrouter-from-openai`

2. Load source-of-truth references.
- Always load `references/provider-docs-index.md` first.
- Then load `references/provider-routing.md`.
- Then load only detected provider sections from:
  - `references/provider-playbooks.md`
  - `references/integration-cookbook.md`

3. Confirm version posture.
- Run `/home/codespace/.codex/skills/workflow-automation/scripts/integration-version-report.sh [repo-root] --check-latest`.
- Read `references/provider-version-watch.md`.
- For periodic maintenance, refresh watch file with:
  - `scripts/refresh-provider-version-watch.sh`

4. Sync docs before code changes.
- Use Context7 for package-version docs.
- Cross-check behavior against official docs from `provider-docs-index.md`.
- If examples conflict with local versions, prefer version-matched behavior and call out mismatch.

5. Apply production checklists.
- Use `references/integration-checklists.md` for quick pass.
- Use `references/production-troubleshooting-checklist.md` for release gates and incident response.

6. Emit evidence with the answer.
- Include provider URLs, package versions (local + latest), Context7 sources, and unresolved gaps.

## Output Contract
- `Detected providers`.
- `Version assumptions` (declared + resolved + latest when available).
- `Docs checked` (provider + URL).
- `Breaking-change risks` (major drift and migration links).
- `Behavior mismatches` (`none` if none).
- `Production-readiness gaps` (if any).

## Guardrails
- Do not rely on memory for provider webhook/auth details.
- Do not assume payload field parity across providers.
- Separate `current code behavior` from `doc-expected behavior`.
- If live latest version checks fail, state network/tooling blocker and continue with local evidence.
