#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$(pwd)}"
OPENROUTER_MODE="${2:-}"

if [[ ! -d "$ROOT" ]]; then
  echo "Root not found: $ROOT" >&2
  exit 1
fi

if ! command -v node >/dev/null 2>&1; then
  echo "node is required for dependency scan" >&2
  exit 1
fi

echo "Integration surface report"
echo "Repo root: $ROOT"
if [[ "$OPENROUTER_MODE" == "--include-openrouter-from-openai" ]]; then
  echo "openrouter mode: include when openai dependency is present"
fi
echo

node - "$ROOT" "$OPENROUTER_MODE" <<'NODE'
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const root = process.argv[2];
const openrouterMode = process.argv[3];

const providers = {
  twilio: {
    deps: ['twilio'],
    docs: ['https://www.twilio.com/docs/voice', 'https://www.twilio.com/docs/messaging'],
    refs: ['provider-playbooks.md#twilio', 'integration-cookbook.md#twilio'],
    runtimeRegex: /X-Twilio-Signature|TWILIO_|VoiceResponse|twiml/i,
  },
  vonage: {
    deps: ['@vonage/server-sdk'],
    docs: ['https://developer.vonage.com/en/voice/voice-api/overview', 'https://developer.vonage.com/en/messaging/sms/overview'],
    refs: ['provider-playbooks.md#vonage', 'integration-cookbook.md#vonage'],
    runtimeRegex: /x-vonage-signature|x-nexmo-signature|VONAGE_|NCCO|vonage/i,
  },
  aws: {
    deps: ['@aws-sdk/client-connect', '@aws-sdk/client-pinpoint', '@aws-sdk/client-polly', '@aws-sdk/client-transcribe-streaming'],
    docs: ['https://docs.aws.amazon.com/sdk-for-javascript/v3/developer-guide/welcome.html', 'https://docs.aws.amazon.com/connect/latest/APIReference/Welcome.html'],
    refs: ['provider-playbooks.md#aws', 'integration-cookbook.md#aws-sdk-v3'],
    runtimeRegex: /@aws-sdk|ConnectClient|StartOutboundVoiceContact|PinpointClient|AWS_/i,
  },
  openrouter: {
    deps: [],
    docs: ['https://openrouter.ai/docs', 'https://openrouter.ai/docs/api-reference/overview'],
    refs: ['provider-playbooks.md#openrouter', 'integration-cookbook.md#openrouter'],
    runtimeRegex: /openrouter\.ai|OPENROUTER_|HTTP-Referer|X-Title/i,
  },
  deepgram: {
    deps: ['@deepgram/sdk'],
    docs: ['https://developers.deepgram.com/docs', 'https://developers.deepgram.com/reference/listen-live'],
    refs: ['provider-playbooks.md#deepgram', 'integration-cookbook.md#deepgram'],
    runtimeRegex: /DEEPGRAM_|LiveTranscriptionEvents|listen\.live|@deepgram\/sdk/i,
  },
  grammy: {
    deps: ['grammy', '@grammyjs/conversations'],
    docs: ['https://grammy.dev/', 'https://grammy.dev/plugins/conversations'],
    refs: ['provider-playbooks.md#grammy', 'integration-cookbook.md#grammy'],
    runtimeRegex: /grammy|@grammyjs|bot\.command\(|conversations\(/i,
  },
};

function walk(dir, out = []) {
  const entries = fs.readdirSync(dir, { withFileTypes: true });
  for (const ent of entries) {
    if (ent.name === 'node_modules' || ent.name.startsWith('.git')) continue;
    const full = path.join(dir, ent.name);
    if (ent.isDirectory()) walk(full, out);
    else if (ent.isFile() && ent.name === 'package.json') out.push(full);
  }
  return out;
}

function addHit(map, provider, row) {
  if (!map.has(provider)) map.set(provider, []);
  const rows = map.get(provider);
  const key = `${row.file || '(runtime)'}|${row.dep || '(runtime)'}|${row.version || '(runtime)'}`;
  const exists = rows.some((r) => `${r.file || '(runtime)'}|${r.dep || '(runtime)'}|${r.version || '(runtime)'}` === key);
  if (!exists) rows.push(row);
}

const packageFiles = walk(root).sort();
const hitMap = new Map();
const openaiHits = [];

for (const pkgFile of packageFiles) {
  const data = (() => {
    try {
      return JSON.parse(fs.readFileSync(pkgFile, 'utf8'));
    } catch {
      return null;
    }
  })();
  if (!data) continue;

  const depMap = {
    ...(data.dependencies || {}),
    ...(data.devDependencies || {}),
    ...(data.optionalDependencies || {}),
    ...(data.peerDependencies || {}),
  };

  for (const [provider, info] of Object.entries(providers)) {
    for (const dep of info.deps) {
      if (!depMap[dep]) continue;
      addHit(hitMap, provider, { file: pkgFile, dep, version: depMap[dep] });
    }
  }

  if (depMap.openai) {
    openaiHits.push({ file: pkgFile, dep: 'openai', version: depMap.openai });
  }
}

let rgOut = '';
try {
  const pattern = [
    'openrouter\\.ai',
    'OPENROUTER_',
    'HTTP-Referer',
    'X-Title',
    'X-Twilio-Signature',
    'x-vonage-signature',
    'x-nexmo-signature',
    'TWILIO_',
    'VONAGE_',
    'DEEPGRAM_',
    '@grammyjs',
    'StartOutboundVoiceContact',
    'ConnectClient',
    'VoiceResponse',
    'NCCO',
    'listen\\.live',
  ].join('|');

  rgOut = execSync(
    `rg -n --hidden -g '!**/node_modules/**' -g '!**/.git/**' '${pattern}' ${JSON.stringify(root)}`,
    { stdio: ['ignore', 'pipe', 'ignore'] }
  ).toString();
} catch {
  rgOut = '';
}

for (const [provider, info] of Object.entries(providers)) {
  if (info.runtimeRegex && info.runtimeRegex.test(rgOut)) {
    addHit(hitMap, provider, { file: '(runtime-signal)', dep: '(signal)', version: '(n/a)' });
  }
}

const openrouterBySignal = providers.openrouter.runtimeRegex.test(rgOut);
const openrouterByFlag = openrouterMode === '--include-openrouter-from-openai' && openaiHits.length > 0;
if (openrouterBySignal || openrouterByFlag) {
  if (openaiHits.length) {
    for (const row of openaiHits) addHit(hitMap, 'openrouter', row);
  } else {
    addHit(hitMap, 'openrouter', { file: '(runtime-signal)', dep: '(signal)', version: '(n/a)' });
  }
}

const foundProviders = [...hitMap.keys()].sort();

if (!foundProviders.length) {
  console.log('Detected providers: (none)');
  console.log('Recommendation: run generic workflow automation only.');
  process.exit(0);
}

console.log(`Detected providers: ${foundProviders.join(', ')}`);
console.log('');

console.log('Package hits:');
for (const provider of foundProviders) {
  const rows = hitMap.get(provider) || [];
  if (!rows.length) {
    console.log(`- ${provider}: (runtime signal only)`);
    continue;
  }

  for (const row of rows) {
    if (row.dep === '(signal)') {
      console.log(`- ${provider}: runtime-signal detected`);
    } else {
      console.log(`- ${provider}: ${row.dep}=${row.version} (${row.file})`);
    }
  }
}

console.log('');
console.log('Recommended references:');
console.log('- /home/codespace/.codex/skills/integration-docs-kit/references/provider-docs-index.md');
console.log('- /home/codespace/.codex/skills/integration-docs-kit/references/provider-version-watch.md');
console.log('- /home/codespace/.codex/skills/integration-docs-kit/references/provider-routing.md');
console.log('- /home/codespace/.codex/skills/integration-docs-kit/references/production-troubleshooting-checklist.md');
for (const provider of foundProviders) {
  const refs = providers[provider].refs || [];
  for (const ref of refs) {
    console.log(`- /home/codespace/.codex/skills/integration-docs-kit/references/${ref}`);
  }
}

console.log('');
console.log('Official docs to verify:');
for (const provider of foundProviders) {
  for (const url of providers[provider].docs || []) {
    console.log(`- ${provider}: ${url}`);
  }
}
NODE
