#!/usr/bin/env bash
set -euo pipefail

OUT_FILE="${1:-$HOME/.codex/skills/integration-docs-kit/references/provider-version-watch.md}"

node - "$OUT_FILE" <<'NODE'
const fs = require('fs');
const { spawnSync } = require('child_process');

const outFile = process.argv[2];

const targets = [
  { provider: 'Twilio', pkg: 'twilio' },
  { provider: 'Vonage', pkg: '@vonage/server-sdk' },
  { provider: 'AWS Connect', pkg: '@aws-sdk/client-connect' },
  { provider: 'AWS Pinpoint', pkg: '@aws-sdk/client-pinpoint' },
  { provider: 'AWS Polly', pkg: '@aws-sdk/client-polly' },
  { provider: 'AWS Transcribe Streaming', pkg: '@aws-sdk/client-transcribe-streaming' },
  { provider: 'OpenAI SDK (for OpenRouter-compatible clients)', pkg: 'openai' },
  { provider: 'OpenRouter SDK', pkg: '@openrouter/sdk' },
  { provider: 'Deepgram', pkg: '@deepgram/sdk' },
  { provider: 'grammY', pkg: 'grammy' },
  { provider: 'grammY conversations', pkg: '@grammyjs/conversations' },
];

function npmView(pkg, field) {
  const res = spawnSync('npm', ['view', pkg, field], {
    encoding: 'utf8',
    timeout: 20000,
  });
  if (res.status !== 0) {
    return null;
  }
  return (res.stdout || '').trim() || null;
}

const rows = targets.map(({ provider, pkg }) => {
  const latest = npmView(pkg, 'version');
  const modified = npmView(pkg, 'time.modified');
  return { provider, pkg, latest: latest || 'unavailable', modified: modified || 'unavailable' };
});

const now = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');

const lines = [];
lines.push('# Provider Version Watch');
lines.push('');
lines.push(`Last updated: ${now}`);
lines.push('Source commands: `npm view <package> version` and `npm view <package> time.modified`');
lines.push('');
lines.push('## Latest stable SDK/package versions');
for (const row of rows) {
  lines.push(`- ${row.provider} (\`${row.pkg}\`): \`${row.latest}\` (published \`${row.modified}\`)`);
}
lines.push('');
lines.push('## Breaking change watchlist');
lines.push('- Twilio Node releases: https://github.com/twilio/twilio-node/releases');
lines.push('- Vonage Node SDK releases: https://github.com/Vonage/vonage-node-sdk/releases');
lines.push('- AWS SDK JS v3 releases: https://github.com/aws/aws-sdk-js-v3/releases');
lines.push('- OpenAI Node releases: https://github.com/openai/openai-node/releases');
lines.push('- Deepgram JS SDK migration guide: https://github.com/deepgram/deepgram-js-sdk/blob/main/MIGRATION.md');
lines.push('- grammY releases: https://github.com/grammyjs/grammY/releases');
lines.push('- grammY conversations releases: https://github.com/grammyjs/conversations/releases');
lines.push('');
lines.push('## Update policy');
lines.push('1. Refresh this file weekly and before major integration work.');
lines.push('2. On each major version drift, annotate migration risks in implementation/review output.');
lines.push('3. Do not merge major upgrades without running integration parity tests (webhooks, auth, retries, terminal-state cleanup).');
lines.push('');

fs.writeFileSync(outFile, lines.join('\n'));
console.log(`Wrote ${outFile}`);
NODE
