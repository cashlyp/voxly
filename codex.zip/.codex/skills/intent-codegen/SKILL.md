---
name: intent-codegen
description: Use when the user asks to implement features or generate code that must match existing project architecture, conventions, and intent. Focuses on constraint extraction, convention matching, minimal diffs, and verification.
---

# Intent Codegen

Use this skill when writing or modifying code so outputs align with user intent and repository conventions.

## Goals
- Convert ambiguous requests into explicit implementation constraints.
- Match local architecture, naming, style, and error-handling patterns.
- Produce small, reviewable diffs with behavior-preserving defaults.

## Workflow
1. Extract intent contract.
- Required outcomes.
- Non-goals and constraints.
- Backward-compatibility/API requirements.
- Performance/security boundaries.

2. Read before writing.
- Find the nearest existing implementation of similar behavior.
- Reuse existing abstractions before creating new ones.
- Match conventions from adjacent files (naming, typing, logging, error format, tests).

3. Documentation sync (required for provider/API work).
- If touching Twilio, Vonage, AWS, OpenRouter, Deepgram, or grammY, run:
  - `/home/codespace/.codex/skills/integration-docs-kit/scripts/detect-integration-surface.sh [repo-root]`
  - `/home/codespace/.codex/skills/workflow-automation/scripts/integration-version-report.sh [repo-root] --check-latest`
- Then load:
  - `/home/codespace/.codex/skills/integration-docs-kit/references/provider-docs-index.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/provider-version-watch.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/provider-playbooks.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/integration-cookbook.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/integration-checklists.md`
- Use Context7 first for package-version docs; then confirm behavior against official provider docs.

4. Plan minimal change set.
- Prefer extension over rewrite.
- Keep edits localized.
- Avoid adding dependencies unless explicitly justified.

5. Implement with convention parity.
- Preserve public contracts unless asked to break them.
- Keep function scope narrow and explicit.
- Add succinct comments only where logic is non-obvious.

6. Verify.
- Run fastest relevant tests/lint/type-check commands.
- Validate changed behavior and likely regressions.
- Report skipped checks and why.

## Output Contract
- State assumptions explicitly.
- Summarize files touched and behavioral impact.
- Include exact verification commands run.
- Call out residual risks or follow-ups.
- For provider work, include local and latest versions plus docs consulted.

## Guardrails
- No drive-by formatting-only diffs.
- No silent behavior changes.
- No speculative refactors during feature work.
