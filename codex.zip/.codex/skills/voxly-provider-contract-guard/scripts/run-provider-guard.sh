#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-/workspaces/voxly}"
KIT_ROOT="/home/codespace/.codex/skills/integration-docs-kit"
AUTO_ROOT="/home/codespace/.codex/skills/workflow-automation"

if [[ ! -d "$REPO_ROOT" ]]; then
  echo "[guard] repo root not found: $REPO_ROOT" >&2
  exit 1
fi

echo "[guard] repo: $REPO_ROOT"

if [[ -x "$KIT_ROOT/scripts/detect-integration-surface.sh" ]]; then
  echo "[guard] detecting provider surface"
  "$KIT_ROOT/scripts/detect-integration-surface.sh" "$REPO_ROOT"
else
  echo "[guard] missing detect-integration-surface.sh" >&2
fi

if [[ -x "$AUTO_ROOT/scripts/integration-version-report.sh" ]]; then
  echo "[guard] checking provider package versions"
  "$AUTO_ROOT/scripts/integration-version-report.sh" "$REPO_ROOT" --check-latest
else
  echo "[guard] missing integration-version-report.sh" >&2
fi

if [[ -f "$REPO_ROOT/api/package.json" ]]; then
  echo "[guard] running api validation commands"
  npm --prefix "$REPO_ROOT/api" run validate:profiles
  npm --prefix "$REPO_ROOT/api" run preflight:provider
  npm --prefix "$REPO_ROOT/api" run parity:providers
else
  echo "[guard] skipping api checks; api/package.json not found"
fi

if [[ -f "$REPO_ROOT/bot/package.json" ]]; then
  echo "[guard] running bot baseline test command"
  npm --prefix "$REPO_ROOT/bot" run test
else
  echo "[guard] skipping bot checks; bot/package.json not found"
fi

echo "[guard] complete"
