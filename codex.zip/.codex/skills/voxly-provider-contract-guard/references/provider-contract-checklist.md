# Provider Contract Checklist (Voxly)

Use this checklist before and after provider-touching changes.

## Pre-change

- Confirm provider(s) affected and entry points touched.
- Confirm signature/auth verification mechanism remains intact.
- Confirm callback path and expected event/status types.
- Confirm idempotency handling for retries/duplicate callbacks.
- Confirm fallback behavior for missing optional fields.

## Post-change

- Validate profile packs and provider preflight/parity commands.
- Run targeted tests for touched webhook/service/function files.
- Confirm non-provider paths remain unchanged.
- Confirm error logs do not include secrets or raw credentials.
- Document behavior mismatch (if any) between local code and provider docs.

## Required response evidence

- Providers detected
- Docs checked
- Version assumptions
- Commands run and result
- Remaining risks/unverified assumptions
