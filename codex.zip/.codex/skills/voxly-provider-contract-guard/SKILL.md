---
name: voxly-provider-contract-guard
description: Use for Voxly provider-facing changes to enforce docs-backed webhook/auth contract checks, version drift detection, and deterministic provider validation commands.
---

# Voxly Provider Contract Guard

Use this skill for Voxly changes that can affect provider behavior, especially webhook/auth/callback contracts.

## Trigger Conditions

Use this skill when any request touches:
- `api/app.js`
- `api/routes/sms.js`
- `api/controllers/*webhook*`
- `api/services/*` when provider SDKs or callback payloads are involved
- `api/functions/*` that call Twilio, Vonage, AWS, OpenRouter, or Deepgram
- `bot/*` when grammY/provider behavior is changed

Use this skill for:
- provider integration implementation
- callback/status handling updates
- auth/signature verification changes
- payload mapping/normalization logic changes
- provider production-readiness reviews

## Core Workflow (strict order)

1. Detect provider surface.
- Run `/home/codespace/.codex/skills/integration-docs-kit/scripts/detect-integration-surface.sh [repo-root]`.

2. Confirm version posture.
- Run `/home/codespace/.codex/skills/workflow-automation/scripts/integration-version-report.sh [repo-root] --check-latest`.

3. Load docs-first references.
- Load `/home/codespace/.codex/skills/integration-docs-kit/references/provider-docs-index.md` first.
- Then load `/home/codespace/.codex/skills/integration-docs-kit/references/provider-routing.md`.
- Then load only provider-relevant sections from:
  - `/home/codespace/.codex/skills/integration-docs-kit/references/provider-playbooks.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/integration-cookbook.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/integration-checklists.md`
- Then apply local checklist:
  - `references/provider-contract-checklist.md`

4. Validate contract-critical behavior before edits.
- Confirm webhook signature/auth scheme.
- Confirm required payload fields and status mapping.
- Confirm callback retry semantics and idempotency expectations.
- If docs and local behavior differ, explicitly document mismatch before patching.

5. Make smallest safe patch.
- Preserve existing provider-neutral behavior unless change is intentional.
- Add guardrails for missing/invalid provider payload fields.
- Prefer targeted tests/smoke checks over broad rewrites.

6. Run deterministic verification.
- Run `scripts/run-provider-guard.sh [repo-root]` from this skill directory.
- If tests for touched files exist, run targeted tests explicitly.

7. Emit evidence contract in response.
- Include detected providers, docs checked, version assumptions, commands run, and residual risks.

## Output Contract (required)

Always include:
- `Skills used and why`
- `Providers detected`
- `Docs checked`
- `Version assumptions`
- `Validation run (commands + result)`
- `Behavior mismatches`
- `Remaining risks/unverified assumptions`

## Fail-Closed Rules

- If webhook/auth contract evidence is missing, do not apply risky behavior changes.
- Ask one targeted question only if no safe default exists.
- If tests cannot run, state exact commands that must be run and why they were skipped.

## Fast Path Command

From this skill directory:
- `scripts/run-provider-guard.sh /workspaces/voxly`

This command executes the minimum deterministic checks for provider-touching Voxly changes.
