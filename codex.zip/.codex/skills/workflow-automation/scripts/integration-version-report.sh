#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
ROOT_SET=0
CHECK_LATEST=0

for arg in "$@"; do
  case "$arg" in
    --check-latest)
      CHECK_LATEST=1
      ;;
    --*)
      echo "Unknown flag: $arg" >&2
      echo "Usage: integration-version-report.sh [repo-root] [--check-latest]" >&2
      exit 1
      ;;
    *)
      if [[ $ROOT_SET -eq 1 ]]; then
        echo "Unexpected extra positional argument: $arg" >&2
        echo "Usage: integration-version-report.sh [repo-root] [--check-latest]" >&2
        exit 1
      fi
      ROOT="$arg"
      ROOT_SET=1
      ;;
  esac
done

if [[ ! -d "$ROOT" ]]; then
  echo "Root not found: $ROOT" >&2
  exit 1
fi

echo "Integration package version report"
echo "Repo root: $ROOT"
if [[ $CHECK_LATEST -eq 1 ]]; then
  echo "latest check: enabled (uses npm registry)"
fi
echo

mapfile -t PKGS < <(find "$ROOT" -type f -name package.json -not -path '*/node_modules/*' | sort)

if [[ ${#PKGS[@]} -eq 0 ]]; then
  echo "No package.json files found."
  exit 0
fi

for pkg in "${PKGS[@]}"; do
  dir="$(dirname "$pkg")"
  echo "== $dir"

  node - "$pkg" "$dir" "$ROOT" "$CHECK_LATEST" <<'NODE'
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const pkgPath = process.argv[2];
const pkgDir = process.argv[3];
const root = process.argv[4];
const checkLatest = process.argv[5] === '1';

const targets = [
  'twilio',
  '@vonage/server-sdk',
  '@aws-sdk/client-connect',
  '@aws-sdk/client-pinpoint',
  '@aws-sdk/client-polly',
  '@aws-sdk/client-transcribe-streaming',
  'openai',
  '@openrouter/sdk',
  '@deepgram/sdk',
  'grammy',
  '@grammyjs/conversations',
];

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return null;
  }
}

function findNearestLock(startDir, stopDir) {
  let dir = startDir;
  const stop = path.resolve(stopDir);

  while (true) {
    const lockPath = path.join(dir, 'package-lock.json');
    if (fs.existsSync(lockPath)) return lockPath;

    const parent = path.dirname(dir);
    if (parent === dir) break;
    if (!path.resolve(parent).startsWith(stop)) break;
    dir = parent;
  }

  return null;
}

function resolvedFromLock(lock, depName) {
  const versions = new Set();

  if (lock && lock.packages && typeof lock.packages === 'object') {
    for (const [key, value] of Object.entries(lock.packages)) {
      if (!value || typeof value !== 'object') continue;
      if (key === `node_modules/${depName}` || key.endsWith(`/node_modules/${depName}`)) {
        if (value.version) versions.add(String(value.version));
      }
    }
  }

  if (
    versions.size === 0 &&
    lock &&
    lock.dependencies &&
    lock.dependencies[depName] &&
    lock.dependencies[depName].version
  ) {
    versions.add(String(lock.dependencies[depName].version));
  }

  return [...versions].sort();
}

function parseSemver(input) {
  const m = String(input || '').match(/(\d+)\.(\d+)\.(\d+)/);
  if (!m) return null;
  return { major: Number(m[1]), minor: Number(m[2]), patch: Number(m[3]) };
}

function compareVersions(current, latest) {
  const c = parseSemver(current);
  const l = parseSemver(latest);
  if (!c || !l) return 'unknown';
  if (c.major !== l.major) return c.major < l.major ? 'major' : 'ahead';
  if (c.minor !== l.minor) return c.minor < l.minor ? 'minor' : 'ahead';
  if (c.patch !== l.patch) return c.patch < l.patch ? 'patch' : 'ahead';
  return 'current';
}

const latestCache = new Map();
function latestFromNpm(depName) {
  if (latestCache.has(depName)) return latestCache.get(depName);
  const out = spawnSync('npm', ['view', depName, 'version'], {
    encoding: 'utf8',
    timeout: 15000,
  });
  const value = out.status === 0 ? String(out.stdout || '').trim() : '';
  const latest = value || 'unavailable';
  latestCache.set(depName, latest);
  return latest;
}

const pkg = readJson(pkgPath) || {};
const deps = {
  ...(pkg.dependencies || {}),
  ...(pkg.devDependencies || {}),
  ...(pkg.optionalDependencies || {}),
  ...(pkg.peerDependencies || {}),
};

const lockPath = findNearestLock(pkgDir, root);
const lockJson = lockPath ? readJson(lockPath) : null;

if (lockPath) {
  console.log(`lockfile: ${lockPath}`);
} else {
  console.log('lockfile: (not found)');
}

let found = 0;
for (const name of targets) {
  const declared = deps[name];
  if (!declared) continue;

  found += 1;
  const resolved = lockJson ? resolvedFromLock(lockJson, name) : [];
  const resolvedDisplay = resolved.length ? resolved.join(',') : '(not found in lockfile)';

  if (!checkLatest) {
    console.log(`${name} declared=${declared} resolved=${resolvedDisplay}`);
    continue;
  }

  const latest = latestFromNpm(name);
  const currentForCompare = resolved.length ? resolved[resolved.length - 1] : declared;
  const drift = latest === 'unavailable' ? 'unknown' : compareVersions(currentForCompare, latest);

  console.log(`${name} declared=${declared} resolved=${resolvedDisplay} latest=${latest} drift=${drift}`);
}

if (!found) {
  console.log('(none of target integration packages found)');
}
NODE

  echo
done

echo "Docs source of truth:"
echo "/home/codespace/.codex/skills/integration-docs-kit/references/provider-docs-index.md"
echo "Version watch reference:"
echo "/home/codespace/.codex/skills/integration-docs-kit/references/provider-version-watch.md"
