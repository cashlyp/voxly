#!/usr/bin/env bash
set -euo pipefail

ROOT="$(pwd)"
ROOT_SET=0
WITH_FAST_CHECKS=0
OPENROUTER_MODE=""
CHECK_LATEST=0
REFRESH_VERSION_WATCH=0

for arg in "$@"; do
  case "$arg" in
    --with-fast-checks)
      WITH_FAST_CHECKS=1
      ;;
    --include-openrouter-from-openai)
      OPENROUTER_MODE="--include-openrouter-from-openai"
      ;;
    --check-latest)
      CHECK_LATEST=1
      ;;
    --refresh-version-watch)
      REFRESH_VERSION_WATCH=1
      ;;
    --*)
      echo "Unknown flag: $arg" >&2
      echo "Usage: workflow-run-integration-audit.sh [repo-root] [--include-openrouter-from-openai] [--check-latest] [--refresh-version-watch] [--with-fast-checks]" >&2
      exit 1
      ;;
    *)
      if [[ $ROOT_SET -eq 1 ]]; then
        echo "Unexpected extra positional argument: $arg" >&2
        echo "Usage: workflow-run-integration-audit.sh [repo-root] [--include-openrouter-from-openai] [--check-latest] [--refresh-version-watch] [--with-fast-checks]" >&2
        exit 1
      fi
      ROOT="$arg"
      ROOT_SET=1
      ;;
  esac
done

if [[ ! -d "$ROOT" ]]; then
  echo "Root not found: $ROOT" >&2
  exit 1
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CODEX_HOME="${CODEX_HOME:-$HOME/.codex}"
SURFACE_SCRIPT="$CODEX_HOME/skills/integration-docs-kit/scripts/detect-integration-surface.sh"
REFRESH_SCRIPT="$CODEX_HOME/skills/integration-docs-kit/scripts/refresh-provider-version-watch.sh"
DISCOVER_SCRIPT="$SCRIPT_DIR/workflow-discover.sh"
VERSIONS_SCRIPT="$SCRIPT_DIR/integration-version-report.sh"
FAST_SCRIPT="$SCRIPT_DIR/workflow-run-fast.sh"

echo "Integration audit"
echo "Repo root: $ROOT"
if [[ -n "$OPENROUTER_MODE" ]]; then
  echo "openrouter mode: include when openai dependency is present"
fi
if [[ $CHECK_LATEST -eq 1 ]]; then
  echo "latest check: enabled"
fi
if [[ $REFRESH_VERSION_WATCH -eq 1 ]]; then
  echo "version watch refresh: enabled"
fi
echo

if [[ -x "$DISCOVER_SCRIPT" ]]; then
  echo "[1/4] Discovering workspace scripts"
  bash "$DISCOVER_SCRIPT" "$ROOT"
  echo
fi

if [[ -x "$SURFACE_SCRIPT" ]]; then
  echo "[2/4] Detecting provider surface"
  if [[ -n "$OPENROUTER_MODE" ]]; then
    bash "$SURFACE_SCRIPT" "$ROOT" "$OPENROUTER_MODE"
  else
    bash "$SURFACE_SCRIPT" "$ROOT"
  fi
  echo
else
  echo "[2/4] Provider surface script missing: $SURFACE_SCRIPT"
  echo
fi

if [[ -x "$VERSIONS_SCRIPT" ]]; then
  echo "[3/4] Reporting integration package versions"
  if [[ $CHECK_LATEST -eq 1 ]]; then
    bash "$VERSIONS_SCRIPT" "$ROOT" --check-latest
  else
    bash "$VERSIONS_SCRIPT" "$ROOT"
  fi
  echo
fi

if [[ $REFRESH_VERSION_WATCH -eq 1 ]]; then
  if [[ -x "$REFRESH_SCRIPT" ]]; then
    echo "[4/4] Refreshing provider version watch"
    bash "$REFRESH_SCRIPT"
    echo
  else
    echo "[4/4] Version watch refresh script missing: $REFRESH_SCRIPT"
    echo
  fi
fi

if [[ $WITH_FAST_CHECKS -eq 1 ]]; then
  if [[ -x "$FAST_SCRIPT" ]]; then
    echo "[optional] Running fast checks"
    bash "$FAST_SCRIPT" "$ROOT"
  else
    echo "workflow-run-fast.sh is missing or not executable"
    exit 1
  fi
fi
