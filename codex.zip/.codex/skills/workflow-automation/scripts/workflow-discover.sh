#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$(pwd)}"

if [[ ! -d "$ROOT" ]]; then
  echo "Root not found: $ROOT" >&2
  exit 1
fi

echo "Repo root: $ROOT"
echo

mapfile -t PKGS < <(find "$ROOT" -type f -name package.json -not -path '*/node_modules/*' | sort)

if [[ ${#PKGS[@]} -eq 0 ]]; then
  echo "No package.json files found."
  exit 0
fi

for pkg in "${PKGS[@]}"; do
  dir="$(dirname "$pkg")"
  echo "== $dir"

  pm="npm"
  if [[ -f "$dir/pnpm-lock.yaml" ]]; then
    pm="pnpm"
  elif [[ -f "$dir/yarn.lock" ]]; then
    pm="yarn"
  fi
  echo "package_manager: $pm"

  node -e '
const fs = require("fs");
const p = process.argv[1];
const data = JSON.parse(fs.readFileSync(p, "utf8"));
const scripts = data.scripts || {};
const keys = Object.keys(scripts);
console.log("scripts:", keys.length ? keys.join(", ") : "(none)");
' "$pkg"

  echo
 done
