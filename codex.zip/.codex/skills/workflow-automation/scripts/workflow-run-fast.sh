#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-$(pwd)}"

if [[ ! -d "$ROOT" ]]; then
  echo "Root not found: $ROOT" >&2
  exit 1
fi

mapfile -t PKGS < <(find "$ROOT" -type f -name package.json -not -path '*/node_modules/*' | sort)

if [[ ${#PKGS[@]} -eq 0 ]]; then
  echo "No package.json files found."
  exit 0
fi

run_cmd() {
  local pm="$1"
  local script="$2"

  if [[ "$pm" == "pnpm" ]]; then
    pnpm run "$script"
  elif [[ "$pm" == "yarn" ]]; then
    yarn "$script"
  else
    npm run "$script"
  fi
}

for pkg in "${PKGS[@]}"; do
  dir="$(dirname "$pkg")"
  echo "== Running fast checks in: $dir"

  pm="npm"
  if [[ -f "$dir/pnpm-lock.yaml" ]]; then
    pm="pnpm"
  elif [[ -f "$dir/yarn.lock" ]]; then
    pm="yarn"
  fi

  mapfile -t ORDER < <(node -e '
const fs = require("fs");
const p = process.argv[1];
const data = JSON.parse(fs.readFileSync(p, "utf8"));
const s = data.scripts || {};
const preferred = ["lint", "typecheck", "test:unit", "test", "check", "build"];
for (const name of preferred) {
  if (s[name]) console.log(name);
}
' "$pkg")

  if [[ ${#ORDER[@]} -eq 0 ]]; then
    echo "No fast-check scripts found."
    echo
    continue
  fi

  (
    cd "$dir"
    for script in "${ORDER[@]}"; do
      echo "+ $pm run $script"
      run_cmd "$pm" "$script"
    done
  )

  echo
 done
