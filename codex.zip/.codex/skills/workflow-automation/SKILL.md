---
name: workflow-automation
description: Use when the user asks to automate repetitive engineering workflows such as setup, refactoring loops, migrations, lint/test runs, and release-prep checks. Includes reusable local scripts.
---

# Workflow Automation

Use this skill to reduce repetitive manual steps and standardize execution.

## Use Cases
- Repo setup and bootstrap checks.
- Fast lint/test/type-check passes.
- Repeatable refactor loops.
- Migration preflight and validation.
- CI-like local sanity runs.
- Integration version/doc alignment checks.

## Default Workflow
1. Detect project layout and available task scripts.
- Run `scripts/workflow-discover.sh [repo-root]`.

2. For provider/API repos, run integration audit first.
- Run `scripts/workflow-run-integration-audit.sh [repo-root] --check-latest`.
- If OpenRouter usage is ambiguous, add:
  - `--include-openrouter-from-openai`
- If you want to refresh the shared version-watch reference, add:
  - `--refresh-version-watch`

3. Execute fast safe checks.
- Run `scripts/workflow-run-fast.sh [repo-root]`.

4. If migration/refactor requested, run loop.
- apply change -> run smallest relevant checks -> inspect failures -> iterate.

5. Emit concise run report.
- Commands run.
- Pass/fail status.
- Next actions for unresolved failures.

## Scripts
- `scripts/workflow-discover.sh`: lists package managers and available scripts per package.
- `scripts/workflow-run-fast.sh`: executes fastest high-signal checks in each detected package.
- `scripts/integration-version-report.sh`: reports declared + resolved lockfile versions and optional latest drift (`--check-latest`).
- `scripts/workflow-run-integration-audit.sh`: orchestrates integration surface scan + version report + optional watch refresh.

## Guardrails
- Prefer fastest relevant checks first.
- Avoid destructive commands by default.
- Stop on first failing command per package and report clearly.
