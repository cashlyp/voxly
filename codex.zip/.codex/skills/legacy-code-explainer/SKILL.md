---
name: legacy-code-explainer
description: Use when the user asks to understand, explain, or untangle complex/legacy code. Produces layered explanations, call/data-flow maps, invariants, and concrete refactor-safe guidance.
---

# Legacy Code Explainer

Use this skill for reverse-engineering complex modules quickly and accurately.

## Analysis Flow
1. Build a structural map.
- Entrypoints and execution triggers.
- Core modules and ownership boundaries.
- External integrations and side effects.

2. Build an execution map.
- Request/event lifecycle from input to output.
- State transitions and persistence points.
- Error paths, retries, and fallback behavior.

3. Documentation sync for integration code.
- If module touches Twilio, Vonage, AWS, OpenRouter, Deepgram, or grammY, run:
  - `/home/codespace/.codex/skills/integration-docs-kit/scripts/detect-integration-surface.sh [repo-root]`
  - `/home/codespace/.codex/skills/workflow-automation/scripts/integration-version-report.sh [repo-root] --check-latest`
- Then load:
  - `/home/codespace/.codex/skills/integration-docs-kit/references/provider-docs-index.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/provider-version-watch.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/provider-playbooks.md`
  - `/home/codespace/.codex/skills/integration-docs-kit/references/integration-cookbook.md`
- Cross-check provider payload fields and auth expectations against current docs.

4. Identify invariants and assumptions.
- Data shape assumptions.
- Ordering/timing assumptions.
- Security/auth assumptions.
- Hidden coupling across modules.

5. Surface risk hotspots.
- High cyclomatic complexity.
- Shared mutable state.
- Silent failure paths.
- Undocumented magic constants and feature flags.

## Explanation Format
- 60-second summary: what the subsystem does.
- Detailed walk-through: step-by-step runtime flow.
- File references: exact files/lines for each key claim.
- Safe-change guidance: where to modify with lowest regression risk.
- Unknowns: explicit list of gaps requiring runtime validation.

## Guardrails
- Distinguish facts from inference.
- Avoid speculative rewrites.
- Prefer concrete examples from current code over generic theory.
- For provider integrations, explicitly separate `code behavior` vs `doc-expected behavior`.
